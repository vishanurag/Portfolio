// -----------------For--Some--Time--Interval----Issues---------------//

MainBody.style.position = "fixed";
MainBody.style.cursor = "wait";

setInterval(() => {
    
    MainBody.style.cursor = "default";
    MainBody.style.position = "sticky";
}, 4000);

// -----------------For--Some--Time--Interval----Issues---------------//