let topref = document.getElementById('topForScroll');

let goToTop = (() => {
    topref.scrollIntoView("scrollBehavour : smooth");
});